CREATE DATABASE  IF NOT EXISTS `youlangme` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `youlangme`;
-- MySQL dump 10.13  Distrib 5.7.9, for Win32 (AMD64)
--
-- Host: localhost    Database: youlangme
-- ------------------------------------------------------
-- Server version	5.7.9-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `board` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) DEFAULT NULL,
  `modified_time` datetime(6) DEFAULT NULL,
  `contents` varchar(2000) DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKctvfif069vuifs8mgeqgejlyc` (`author_id`),
  CONSTRAINT `FKctvfif069vuifs8mgeqgejlyc` FOREIGN KEY (`author_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4006 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (1991,'2021-08-21 14:24:31.503768',NULL,'안녕하세요! 영어 공부하려고 가입했습니다 ^_^',7603),(1992,'2021-08-21 15:24:31.503768',NULL,'매칭은 어떻게 해요?',7603),(1993,'2021-08-22 14:24:31.503768',NULL,'영어 어려워 ㅠ',7603),(1994,'2021-08-25 12:24:31.503768',NULL,'영어 어려워 ㅠ',7603),(1995,'2021-08-26 14:24:31.503768',NULL,'영어 어려워 ㅠ',7603),(1996,'2021-08-26 12:24:31.503768',NULL,'영어 어려워 ㅠ',7603),(1997,'2021-08-26 13:24:31.503768',NULL,'영어 어려워 ㅠ',7603),(1998,'2021-08-27 14:24:31.503768',NULL,'영어 어려워 ㅠ',7603),(1999,'2021-08-28 14:24:31.503768',NULL,'영어 어려워 ㅠ',7603),(2000,'2021-08-29 12:24:31.503768',NULL,'영어 어려워 ㅠ',7603),(2001,'2021-08-29 14:24:31.503768',NULL,'영어 어려워 ㅠ',7603),(2002,'2022-01-03 14:24:31.503768',NULL,'영어 너무 어려워요',7603),(2003,'2022-01-21 14:24:31.503768',NULL,'영어 너무 어려워요',7603),(2004,'2022-01-20 12:24:31.503768',NULL,'영어 너무 어려워요',7603),(2005,'2022-01-22 14:24:31.503768',NULL,'영어 너무 어려워요',7603),(2006,'2022-01-23 14:24:31.503768',NULL,'영어 너무 어려워요',7603),(2007,'2022-01-23 14:24:31.503768',NULL,'영어 너무 어려워요',7603),(2008,'2022-01-24 14:24:31.503768',NULL,'영어 너무 어려워요',7603),(2009,'2022-01-24 14:24:31.503768',NULL,'영어 너무 어려워요',7603),(2010,'2022-01-29 14:24:31.503768',NULL,'영어 공부 재밌어요',7603),(2011,'2022-01-29 12:24:31.503768',NULL,'영어 공부 재밌어요',7603),(2012,'2022-01-29 14:24:31.503768',NULL,'영어 공부 재밌어요',7603),(2013,'2022-01-30 15:24:31.503768',NULL,'영어 공부 재밌어요',7603),(2014,'2022-02-03 14:24:31.503768',NULL,'영어 공부 재밌어요',7603),(2015,'2022-02-03 14:24:31.503768',NULL,'영어 공부 재밌어요',7603),(2016,'2022-02-05 14:24:31.503768',NULL,'영어 공부 재밌어요',7603),(2017,'2022-02-05 14:24:31.503768',NULL,'영어 공부 재밌어요',7603),(2018,'2022-02-07 14:24:31.503768',NULL,'영어 공부 재밌어요',7603),(2019,'2022-02-09 14:24:31.503768',NULL,'오늘 만난 영국 아저씨는 매우 친절했어요 Thank you sir :)',7603),(2020,'2022-02-10 14:24:31.503768',NULL,'Somebody help me!!',7603),(2021,'2022-02-11 14:24:31.503768',NULL,'Slow and steady win the race.  천천히 그리고 꾸준히 가는 자가 경주에서 승리한다.',7603),(2022,'2022-02-21 12:24:31.503768',NULL,'Heaven helps those who help themselves. 하늘은 스스로 돕는 자를 돕는다.',7603),(2023,'2022-02-25 13:24:31.503768',NULL,'오늘 만난 영국 아저씨는 매우 친절했어요 Thank you sir :)',7603),(2024,'2022-02-27 14:24:31.503768',NULL,'Somebody help me!!',7603),(2025,'2022-03-03 14:24:31.503768',NULL,' A little learning is a dangerous thing.',7603),(2026,'2022-03-04 14:24:31.503768',NULL,'Only the educated are free.',7603),(2027,'2022-05-21 14:24:31.503768',NULL,'I have failed over and over again in my life. And that is why I succeed. 그리고 그것이 내가 성공한 이유이다.',7603),(2028,'2022-05-23 14:24:31.503768',NULL,'Nothing great was ever ahcieved without enthusiasm. 위대한 것 치고 열정 없이 이루어진 것은 없다.',7603),(2029,'2022-06-21 14:24:31.503768',NULL,'The chief thing is not learning, but the deed. 진정으로 중요한 것은 배우는 것이 아니라 실천하는 것이다.',7603),(2030,'2022-06-22 14:24:31.503768',NULL,'All our dreams can come true if we have the courage to pursue them.',7603),(2031,'2022-07-21 14:24:31.503768',NULL,' Every failure is a stepping stone to success. 모든 실패는 성공으로 향하는 디딤돌이다.',7603),(2032,'2022-07-23 14:24:31.503768',NULL,'Somebody help me!!',7603),(2033,'2022-07-24 14:24:31.503768',NULL,'오늘 만난 영국 아저씨는 매우 친절했어요 Thank you sir :)',7603),(2034,'2022-08-01 14:24:31.503768',NULL,'Non but a wise man can employ leisure well. 오직 현명한 자만이 여가시간을 잘 활용한다.',7603),(2035,'2022-08-14 14:24:31.503768',NULL,' Patience is bitter, but its fruit is sweet. 인내는 쓰나 그 열매는 달다.',7603),(2036,'2022-08-15 14:24:31.503768',NULL,'영어 공부 힘들지만 youlangme 덕분에 너무 재밌어요!',7603),(2037,'2022-08-16 14:24:31.503768',NULL,'Our patience will achieve more than our force. 우리의 인내는 우리의 힘보다 더 많은 것을 성취한다. ',7603),(3001,'2022-04-23 14:24:31.503768',NULL,'Somebody help me!!',9322),(3002,'2022-04-24 14:24:31.503768',NULL,'오늘 만난 한국 청년은 매우 친절했어요 Thank you :)',9322),(3003,'2022-05-01 14:24:31.503768',NULL,'Non but a wise man can employ leisure well. 오직 현명한 자만이 여가시간을 잘 활용한다.',9322),(3004,'2022-05-14 14:24:31.503768',NULL,' Patience is bitter, but its fruit is sweet. 인내는 쓰나 그 열매는 달다.',9322),(3005,'2022-05-15 14:24:31.503768',NULL,'한국어 공부 힘들지만 youlangme 덕분에 너무 재밌어요! so fun!!',9322),(3006,'2022-06-16 14:24:31.503768',NULL,'Our patience will achieve more than our force. 우리의 인내는 우리의 힘보다 더 많은 것을 성취한다. ',9322),(3007,'2022-07-01 14:24:31.503768',NULL,'Non but a wise man can employ leisure well. 오직 현명한 자만이 여가시간을 잘 활용한다.',9322),(3008,'2022-07-02 14:24:31.503768',NULL,' Patience is bitter, but its fruit is sweet. 인내는 쓰나 그 열매는 달다.',9322),(3009,'2022-07-04 14:24:31.503768',NULL,'한국어 배운지 3개월입니다. 즐거워요',9322),(3010,'2022-07-16 14:24:31.503768',NULL,'Our patience will achieve more than our force. 우리의 인내는 우리의 힘보다 더 많은 것을 성취한다. ',9322),(3011,'2022-07-28 14:24:31.503768',NULL,'Non but a wise man can employ leisure well. 오직 현명한 자만이 여가시간을 잘 활용한다.',9322),(3012,'2022-07-29 14:24:31.503768',NULL,' 꿩 먹고 알 먹는다  Meaning: Kill two birds with one stone',9322),(3013,'2022-08-09 14:24:31.503768',NULL,'한국어 공부 힘들지만 youlangme 덕분에 너무 재밌어요!',9322),(3014,'2022-08-17 14:24:31.503768',NULL,'오늘 배운 재밌는 한국 속담: 낮말은 새가 듣고 밤말은 쥐가 듣는다 (nanmareun saega deutgo bammareun jwiga deunneunda) Meaning: The walls have ears.  Literal Translation: Birds hear the words spoken in the day, and mice hear the words spoken at night',9322),(4001,'2022-04-23 14:24:31.503768',NULL,'Hello world!',9777),(4002,'2022-06-24 14:24:31.503768',NULL,'오늘 만난 한국 친구 매우 재밌었어요! Thank you :)',9777),(4003,'2022-06-29 14:24:31.503768',NULL,'Non but a wise man can employ leisure well. 오직 현명한 자만이 여가시간을 잘 활용한다.',9777),(4004,'2022-07-14 14:24:31.503768',NULL,' Patience is bitter, but its fruit is sweet. 인내는 쓰나 그 열매는 달다.',9777),(4005,'2022-08-15 14:24:31.503768',NULL,'youlangme 덕분에 한국어 공부가 너무 재밌어요! so fun :)',9777);
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:21:33
