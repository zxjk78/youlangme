CREATE DATABASE  IF NOT EXISTS `youlangme` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `youlangme`;
-- MySQL dump 10.13  Distrib 5.7.9, for Win32 (AMD64)
--
-- Host: localhost    Database: youlangme
-- ------------------------------------------------------
-- Server version	5.7.9-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reply`
--

DROP TABLE IF EXISTS `reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reply` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) DEFAULT NULL,
  `modified_time` datetime(6) DEFAULT NULL,
  `contents` varchar(2000) DEFAULT NULL,
  `pid` bigint(20) DEFAULT NULL,
  `board_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKcs9hiip0bv9xxfrgoj0lwv2dt` (`board_id`),
  KEY `FKapyyxlgntertu5okpkr685ir9` (`user_id`),
  CONSTRAINT `FKapyyxlgntertu5okpkr685ir9` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKcs9hiip0bv9xxfrgoj0lwv2dt` FOREIGN KEY (`board_id`) REFERENCES `board` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5002 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reply`
--

LOCK TABLES `reply` WRITE;
/*!40000 ALTER TABLE `reply` DISABLE KEYS */;
INSERT INTO `reply` VALUES (2001,'2022-05-21 14:36:30.397647',NULL,'That is a good phrase',0,2027,9322),(2002,'2022-07-23 14:36:30.397647',NULL,'What is the matter?',0,2032,9322),(2003,'2022-08-15 14:36:30.397647',NULL,'I think so, too!',0,2036,9322),(2004,'2022-08-16 14:36:30.397647',NULL,'What a great article!',0,2037,9322),(3001,'2022-04-23 14:36:30.397647',NULL,'무슨 일이에요??',0,3001,7603),(3002,'2022-05-14 14:36:30.397647',NULL,'good!!',0,3004,9322),(3003,'2022-07-16 14:36:30.397647',NULL,'I think so, too!',0,3010,9322),(3004,'2022-07-29 14:36:30.397647',NULL,'좋은 말이네요~',0,3012,7603),(3005,'2022-08-09 14:36:30.397647',NULL,'저도 그렇게 생각해요!',0,3013,7603),(3006,'2022-08-17 14:36:30.397647',NULL,'한국어를 정말 잘하시는군요!^^',0,3014,7603),(4001,'2022-05-22 14:36:30.397647',NULL,'nice',0,2027,9777),(4002,'2022-07-24 14:36:30.397647',NULL,'May I help you?',0,2032,9777),(4003,'2022-08-15 15:36:30.397647',NULL,'Good Job!',0,2036,9777),(4004,'2022-08-16 15:36:30.397647',NULL,'It is the best post I have seen recently',0,2037,9777),(5001,'2022-08-15 14:36:30.397647',NULL,'저도 그래요^^',0,4005,7603);
/*!40000 ALTER TABLE `reply` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19 11:21:33
